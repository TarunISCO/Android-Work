# EventFolio

EventFolio is an Android Application which helps you in gathering students for various activities based on their interest. 

Objective of this application is to provide a platform for students. Student,who may wish to organize an event for an activity for which he requires other interested students, can create event in the application. The students who wants to participate in that event must mark their presence so that host of the event can calculate the number of interested students and proceed accordingly.


[![Join the chat at https://gitter.im/DeepBench/Lobby](https://badges.gitter.im/Masterminds/glide.svg)](https://gitter.im/DeepBench/Lobby)
[![Code Climate](https://codeclimate.com/github/codeclimate/codeclimate/badges/gpa.svg)](https://codeclimate.com/github/TarunISCO/EventFolio)
[![GitHub issues](https://img.shields.io/github/issues/TarunISCO/EventFolio.svg)](https://github.com/TarunISCO/EventFolio/issues)


### Team Members
* [Tarun Bhardwaj](https://github.com/TarunISCO)(Leader)
* [Monika Singh](https://github.com/monikasingh20)
* [Satyam Kumar](https://github.com/SatyamK23)
* [Shubham Poddar](https://github.com/shubham6966)
* [Rajat Soni](https://github.com/Rajat102)
* [Kshitiz Khinchi](https://github.com/kshitizk1796)
